import hamsterExchange from "./hamster-exchange.png";
import binanceLogo from "./binance-logo.png";
import dollarCoin from "./dollar-coin.png";
import dailyReward from "./daily-reward.png";
import dailyCipher from "./daily-cipher.png";
import dailyCombo from "./daily-combo.png";
import mainCharacter from "./main-character.png";
import hamsterCoin from "./hamster-coin.png";

export {
    hamsterExchange,
    binanceLogo,
    dollarCoin,
    dailyReward,
    dailyCipher,
    dailyCombo,
    mainCharacter,
    hamsterCoin
};